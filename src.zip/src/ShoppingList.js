import React from 'react';
import "./ShoppingList.css";
import ShoppingItem from './ShoppingItem';

const useShoppingList = () => {
  const [items, setItems] = React.useState([]);
  const [total, setTotal] = React.useState(0);

  React.useEffect(() => {
    const storedItems = localStorage.getItem('shoppingListItems');
    if (storedItems) {
      setItems(JSON.parse(storedItems));
    }
    const storedTotal = localStorage.getItem('shoppingListTotal');
    if (storedTotal) {
      setTotal(parseFloat(storedTotal));
    }
  }, []);

  const addItem = (name, price) => {
    const newItem = { name, price, isPurchased: false };
    setItems([...items, newItem]);
    setTotal(total + price);
    localStorage.setItem('shoppingListItems', JSON.stringify([...items, newItem]));
    const storedTotal = localStorage.getItem('shoppingListTotal');
    const newTotal = storedTotal ? parseFloat(storedTotal) + price : price;
    localStorage.setItem('shoppingListTotal', newTotal);
  };

  const toggleItem = (index) => {
    const updatedItems = [...items];
    updatedItems[index].isPurchased = !updatedItems[index].isPurchased;
    setItems(updatedItems);
    localStorage.setItem('shoppingListItems', JSON.stringify(updatedItems));
  };

  const deleteItem = (index) => {
    const deletedItem = items[index];
    setItems(items.filter((_, i) => i !== index));
    if (!deletedItem.isPurchased) {
      setTotal(total - deletedItem.price);
      localStorage.setItem('shoppingListTotal', total - deletedItem.price);
    }
    localStorage.setItem('shoppingListItems', JSON.stringify(items.filter((_, i) => i !== index)));
  };

  return { items, total, addItem, toggleItem, deleteItem };
};

const ShoppingList = () => {
  const { items, total, addItem, toggleItem, deleteItem } = useShoppingList();

  const handleAddItem = () => {
    const name = prompt('Nazwa przedmiotu');
    const price = parseFloat(prompt('Cena'));
    if (name && price) {
      addItem(name, price);
    }
  };

  return (
    <div className="listazak">
      <h2>Lista zakupów</h2>
      <div>
        <button className="addbtn" onClick={handleAddItem}>Dodaj przedmiot</button>
      </div>
      <div>
        {items.map((item, index) => (
          <ShoppingItem
            key={index}
            item={item}
            onToggle={() => toggleItem(index)}
            onDelete={() => deleteItem(index)}
          />
        ))}
      </div>
      <h3>Suma: {total}</h3>
    </div>
  );
};

export default ShoppingList;