import React from 'react';
import "./ShoppingItem.css";
const ShoppingItem = ({ item, onToggle, onDelete }) => {
  return (
    <div className="item">
      <span>Nazwa produktu:{item.name} - Cena:{item.price}</span>
      <br></br>
      <button className={`ifbought ${item.isPurchased ? 'red' : ''}`} onClick={onToggle}>
  {item.isPurchased ? 'Nie zakupiony' : 'Zakupiony'}
</button>

      <button className="delete" onClick={onDelete}><img src="https://www.svgrepo.com/show/491188/bin.svg"></img></button>
    </div>
  );
};

export default ShoppingItem;