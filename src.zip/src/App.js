import React from 'react';
import ShoppingList from './ShoppingList';
import "./App.css"
const App = () => {
  return (
    <div className="main">
      <h1>Aplikacja do tworzenia i zarządzania listą zakupów</h1>
      <ShoppingList />
    </div>
  );
};

export default App;